#include <stdint.h>
#include <sys/types.h>
typedef int64_t crypto_int64;

#define select ed25519_select
